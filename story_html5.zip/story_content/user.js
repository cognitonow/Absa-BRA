function ExecuteScript(strId)
{
  switch (strId)
  {
      case "68VMfdmkx4q":
        Script1();
        break;
      case "6K3y7IHUn2D":
        Script2();
        break;
  }
}

function Script1()
{
  SetStatus("completed")
}

function Script2()
{
  SetStatus("completed")
}

